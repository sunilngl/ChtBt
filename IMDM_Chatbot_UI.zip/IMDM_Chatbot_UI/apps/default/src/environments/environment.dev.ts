import sharedEnvironment from './base';

export const environment = {
  // dev deployment environment settings
  ...sharedEnvironment,
  production: false,
  envName: 'dev',
  CHAT_BASE_URL: 'http://rasa-x-cde-chatbot.origin-ctc-core-nonprod.optum.com',
  auth: {
    clientId: 'ndbui',
    issuer: 'https://keycloak-ndb-chatbot-stage.origin-ctc-core.optum.com/auth/realms/ndb'
  }
};
