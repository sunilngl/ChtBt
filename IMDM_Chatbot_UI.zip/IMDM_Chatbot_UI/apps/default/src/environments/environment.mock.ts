import sharedEnvironment from './base';

export const environment = { // mock environment to imitate prod. environment settings locally
  ...sharedEnvironment,
  production: true,
  envName: 'mock',
  CHAT_BASE_URL: 'http://rasa-x-cde-chatbot.origin-ctc-core-nonprod.optum.com',
  auth: {
    clientId: 'is360ui',
    issuer: 'https://keycloak-is360-phase-2.origin-ctc-core.optum.com/auth/realms/is360'
  }
};


