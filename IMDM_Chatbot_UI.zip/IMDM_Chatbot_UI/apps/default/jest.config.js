module.exports = {
  name: 'default',
  preset: '../../jest.config.js',
  coverageDirectory: '../../coverage/apps/default'
};
