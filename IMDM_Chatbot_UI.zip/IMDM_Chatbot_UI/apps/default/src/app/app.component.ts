import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceWorkerService } from '@default/core';
import { NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators'
import { environment } from '@env/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
  constructor(
    private router: Router
    // private sw: ServiceWorkerService // sw disabled
    ) {
      // if (environment.production) {
        const navEndEvents = router.events.pipe(
          filter(event => event instanceof NavigationEnd)
        );
        navEndEvents.subscribe((event: NavigationEnd) => {
        })
      // }
    }

  ngOnInit() {
    // Check service worker update
    // this.sw.checkSWUpdate(); // sw disabled
  }
}
