import { MenuItemType, MenuItem } from '@nx-starter-kit/navigator';
import { environment } from '@env/environment';

export const defaultMenu: MenuItem[] = [
  // {
  //   name: 'Home',
  //   icon: 'home',
  //   link: '/chatbot'
  // },
  {
    name: 'IMDM Chatbot',
    icon: 'home',
    type: MenuItemType.ExtLink,
    target: '_blank',
    link: 'https://phi-splunk.optum.com/en-US/app/optum_zOS/batch_dashboard?form.field1.earliest=-24h%40h&form.field1.latest=now#en-US/app/optum_zOS/batch_dashboard?form.field1.earliest=-24h%40h&form.field1.latest=now'
  },
  {
    name: 'FAQ',
    type: MenuItemType.DropDown,
    icon: 'contact_support',
    badge: { value: 1, color: 'accent' },
    tooltip: 'FAQ',
    children: [
      {
        name: 'Artifactory',
        icon: '',
        type: MenuItemType.DropDown,
        children: [
          {
            name: 'What is the chargeback information for Artifactory',
            type: MenuItemType.SubmitText,
          },
          {
            name: 'Is there a documentation for Artifactory?',
            type: MenuItemType.SubmitText,
          }
        ]
      },
      {
        name: 'Jenkins',
        icon: '',
        type: MenuItemType.DropDown,
        children: [
          {
            name: 'Can you please help me with chargeback information for Jenkins?',
            type: MenuItemType.SubmitText,
          }
        ]
      }
    ]
  },
  {
    name: 'Contact Us',
    type: MenuItemType.DropDown,
    icon: 'description',
    badge: { value: 1, color: 'accent' },
    tooltip: 'App Details',
    children: [
      {
        name: 'CDE Issues',
        icon: '',
        type: MenuItemType.DropDown,
        children: [
          {
            name: 'Sandan Garapati',
            link: 'mailto:garapati_sandan@optum.com',
            icon: '',
            type: MenuItemType.ExtLink,
            target: '_top',
          },
          {
            name: 'Ravindra Nagella',
            link: 'mailto:ravindra_nagella@optum.com',
            icon: '',
            type: MenuItemType.ExtLink,
            target: '_top',
          }
        ]
      },
      {
        name: 'Chatbot Issues',
        icon: '',
        type: MenuItemType.DropDown,
        children: [
          {
            name: 'Ravindra Nagella',
            link: 'mailto:ravindra_nagella@optum.com',
            icon: '',
            type: MenuItemType.ExtLink,
            target: '_top',
          }
        ]
      }
    ]
  },

];
