import sharedEnvironment from './base';

export const environment = {
  // prod deployment environment settings
  ...sharedEnvironment,
  production: true,
  envName: 'prod',
  CHAT_BASE_URL: 'http://rasa-x-cde-chatbot.origin-ctc-core-nonprod.optum.com',
  auth: {
    clientId: 'ndbui',
    issuer: 'https://keycloak-ndb-chatbot-prod.origin-ctc-core.optum.com/auth/realms/ndb'
  }
};
